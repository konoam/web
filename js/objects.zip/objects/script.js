
let noam = {
    eyes:"brown",
    hair:"brown",
    name:"noam",    
} ;

console.log(noam)

noam.eyes="green"
console.log(noam)
noam.location = {israel:true,
                 city:"tlv"}
console.log(noam.location)
noam.lang ={ english: true, hebrew:true, russion:false}
console.log(noam.lang)










function openWindow(){
    document.getElementById('img').src = 'openW.jpg'

}

function closeWindow(){
    document.getElementById('img').src = 'close.png'
    
}
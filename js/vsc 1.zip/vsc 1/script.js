function addItem () {
    document.getElementById(slist).innerHTML += '<li> עגבניה</li>'
}
function fiveSqr(){
    document.getElementById('textbox').innerHTML = 25
}

function divHundred(){
    alert(100/8)
    alert(100%8)
}

function consoleLog (){
    console.log("Hello" + "World")
}
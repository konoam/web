/*
 function changeBColor()
 {
     document.body.style.backgroundColor ='pink';
 } */
 function changeImage(){
document.getElementById('img').src = 'energy.jpg';
}
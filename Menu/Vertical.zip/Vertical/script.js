function showAbout(){
    document.getElementById('about').style.display='block'
    document.getElementById('products').style.display='none'
    document.getElementById('services').style.display='none'                    
}


function showProducts(){
    document.getElementById('about').style.display='none'
    document.getElementById('products').style.display='block'
    document.getElementById('services').style.display='none'                    
}

function showServices(){
    document.getElementById('about').style.display='none'
    document.getElementById('products').style.display='none'
    document.getElementById('services').style.display='block'                    
}